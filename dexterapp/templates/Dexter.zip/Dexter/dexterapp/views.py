from django.shortcuts import render ,redirect



def root (request):
    return render(request,'welcome.html')


def signin(request):
    return render(request,'login.html')

def all_patients(request):
    return render(request,'all_patients.html')

def all_payments(request):
    return render(request,'all_payments.html')