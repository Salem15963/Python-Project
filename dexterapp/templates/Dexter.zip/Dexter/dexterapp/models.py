from django.db import models

# Create your models here.
# class Doctor(models.Model):
#     first_name=models.CharField(max_length=255)
#     last_name=models.CharField(max_length=255)
#     email=models.EmailField(max_length=255)
#     password=models.CharField(max_length=255)
#     phone=models.IntegerField(null=False)
#     national_id=models.IntegerField(null=False)
#     desc=models.TextField(null=False)
#     role=models.ENUM('ADMIN', 'USER')
#     create_at=models.DateField(auto_now_add=True)
#     update_at=models.DateField(auto_now=True)

# class Clinic(models.Model):
#     name=models.CharField(max_length=255)
#     address=models.CharField(max_length=500)
#     create_at=models.DateField(auto_now_add=True)
#     update_at=models.DateField(auto_now=True)
#     doctor=models.ForeignKey(Doctor, related_name="doctor",on_delete=models.CASCADE)

# class Patient(models.Model):
#     first_name=models.CharField(max_length=255)
#     last_name=models.CharField(max_length=255)
#     national_id=models.IntegerField(null=False)
#     gender=models.('F', 'M')
#     phone=models.IntegerField(null=False)
#     email=models.EmailField(max_length=255)
#     desc=models.TextField(null=False)
#     date_of_bith=models.DateField(null=False)
#     last_visit_date=models.DateField(null=False)
#     create_at=models.DateField(auto_now_add=True)
#     update_at=models.DateField(auto_now=True)
#     clinic=models.ForeignKey(Clinic, related_name="clinic",on_delete=models.CASCADE)


# class Appointment(models.Model):
#     start_time=models.DateField()
#     end_time=models.DateField()
#     title=models.CharField(max_length=255)
#     doctor=models.ForeignKey(Doctor, related_name="doctor",on_delete=models.CASCADE)
#     patient=models.ForeignKey(Patient, related_name="patient",on_delete=models.CASCADE)
#     create_at=models.DateField(auto_now_add=True)
#     update_at=models.DateField(auto_now=True)

# class Payment(models.Model):
#     amount=models.IntegerField(null=True)
#     date=models.DateField()
#     method=models.ENUM('C', 'M')
#     create_at=models.DateField(auto_now_add=True)
#     update_at=models.DateField(auto_now=True)
