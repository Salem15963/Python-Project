from django.apps import AppConfig


class DexterappConfig(AppConfig):
    name = 'dexterapp'
