from django.urls import path
from . import views

urlpatterns = [
    path('', views.root),
    path('signin',views.signin),
    path('allpatients',views.all_patients),
    path('allpayments',views.all_payments),
]